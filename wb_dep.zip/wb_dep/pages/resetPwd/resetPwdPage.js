define(function(require) {
  'use strict';
  var Backbone      = require('backbone'),
      _             = require('underscore'),
      resetPwdTemplate  = require('text!./resetPwdTemplate.html'),
      Layout        = require('layouts/loginLayout/layout');
  var ResetPwdPage = Backbone.View.extend({
    template: _.template(resetPwdTemplate),
    render: function() {		
	  require(['jquery','jqueryui','jquery_validate','datatables','bootstrap','store','workbee','mailcheck', 'cookiepopup','bootstrap_slider','validator','md5'], function($){ 
		 $(document).ready(function() {		  
		   $('#headerName').html("Reset password");	     
			 getBrowserLanguage(bLanguage);	
			
				setTimeout(function(){					
            	   if( availableTrans.match(new RegExp("(?:^|,)"+ store.get("sCountrycode")+"(?:,|$)"))) {
					   require([baseURL+'libs/jquery/localization/messages_'+store.get("sCountrycode")+".js"], function ($) {});	
					} else {
					   require([baseURL+'libs/jquery/localization/messages_gb.js'], function ($) {});	
					}
				}, 1000); 		
											
				$(document).on("click", '.sLanguage', function (e) {	
				   var language = $(this).attr('id').toLowerCase();					
				   require([baseURL+'libs/jquery/localization/messages_'+language+".js"], function ($) {});					 
				});						
					
				$(function() {						
					var optionss = {};
					optionss.ui = {
						container: "#pwd-container",
						showVerdictsInsideProgressBar: true,
						viewports: {
							progress: ".pwstrength_viewport_progress"
						}
					};			
					$('#respassword').pwstrength(optionss);		
					
					$.validator.addMethod(
						'ContainsAtLeastOneDigit',
						function (value) {
						return (/[0-9]/).test(value);
						},
						'<span class="sTranslate" key="_create_account_pass_cri_1_">Uw wachtwoord moet minimaal een cijfer bevatten.</span>'
						);
						
						$.validator.addMethod(
						'ContainsAtLeastOneCapitalLetter',
						function (value) {
							return (/[A-Z]/).test(value);
						},
						'<span class="sTranslate" key="_create_account_pass_cri_2_">Uw wachtwoord moet minstens een hoofdletter bevatten.</span>'
					);					  		
					// Validation
					$("#workbee-pwd-resseter").validate({
						// Rules for form validation
						rules : {							
							respassword : {						
								ContainsAtLeastOneDigit: true,
								ContainsAtLeastOneCapitalLetter: true,
								minlength: 8,
								required: true
							},
							rrespassword : {
								required : true,
								minlength : 3,
								maxlength : 20,
								equalTo : '#respassword'
							}					
						},			
						// Ajax form submition
						submitHandler : function(form) {	
						//alert($("#respassword").val());						
							 fncResetPassword($("#respassword").val());				
							return false;
						},
						// Do not change code below
						errorPlacement : function(error, element) {
							error.insertAfter(element.parent());
						}
					});					
				});				
					
				 function fncResetPassword(pwd) {	
				   $("#msgbox").removeClass().addClass('messagebox').html('<i class="fa fa-gear fa-2x fa-spin"></i>  ....').fadeIn(1000);							
					$.ajax({
						type: "GET",
						url: restURL +"resetpwd?guid="+getUrlVars()["guid"]+"&langcode="+store.get("sCountrycode"),	
						data: {password:md5(pwd)}, 				
						dataType: "json",
						success: function(sResponse) {						
							if (sResponse.result == 'OK'){	
							
								 $("#msgbox").fadeTo(400,0.1,function(){								
										$(this).html('<i class="fa fa-gear fa-2x fa-spin"></i>  .....').addClass('messageboxok').fadeTo(900,1,function(){ 							 
											setTimeout(function() {	
												$('#forgrtFormDiv').hide();	
												$('#resetMessageSpan').css("display", "block");			
												 $('#resetMessageSpan').html("<a href='" +baseURL + "'#/login' class='sTranslate' key='_pwd_gereset_bericht_'> Uw wachtwoord is succesvol gereset. U wordt automatisch doorgestuurd naar login pagina. Anders klik hier om in te loggen.</p><br>");	
												 $("#msgbox").hide();
												  window.location.href =  baseURL+'#/login';												
											}, 3000);									
										});
									});		
															
							} else if (sResponse.error){
							  $('#resetMessageSpan').html("<p style='color: #FECB01!important;'>"+sResponse.error+"</p>");
							  $("#msgbox").hide();
							}
						},
						error: function (xhr, ajaxOptions, thrownError) {
							   $('#resetMessageSpan').html("<p style='color: #FECB01!important;'>"+xhr.thrownError+"</p>");	
								$("#msgbox").hide();		
						}
					 });
				} 		
		
		   });// ready
		
	    });// require
      this.$el.html(this.template(this)); 
      return this;	
    } //render
  });//Backbone view
  return Layout.extend({
    content: ResetPwdPage
  });
});


