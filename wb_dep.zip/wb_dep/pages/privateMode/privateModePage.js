define(function(require) {
  'use strict';
  var Backbone          = require('backbone'),
      _                 = require('underscore'),
      privateModeTemplate  = require('text!./privateModeTemplate.html'),
      Layout            = require('layouts/privateModeLayout/layout');

  var PrivateModePage =  Backbone.View.extend({
    template: _.template(privateModeTemplate),

    render: function() {
		 require(['jquery', 'store'], function($){ 			
			$(document).ready(function(){	
			  $('#headerName').html("Private mode");		 
			  // show loading overlay								
			  $('body').prepend('<div id="loading-overlay" style="margin-top: -2% !important;"> <div id="loading-spin"> <i class="fa fa-spinner fa-pulse fa-3x fa-fw margin-bottom"></i></div></div>');	
				// grab browser language, 			
				 (bLanguage === "en") ? bLanguage = "gb": bLanguage = bLanguage; 							
				 (typeof bLanguage === "undefined" || bLanguage === null) ? bLanguage = "gb": bLanguage = bLanguage;  				
				  setTimeout(function(){								
					//fncGetLangInterfaceItems(bLanguage);							
				  }, 1000); 
				
			});	
		 });			
		
      this.$el.html(this.template(this));
      return this;
    }
  });

  return Layout.extend({
    content: PrivateModePage
  });
});
