define(function(require) {
  'use strict';
  var Backbone          = require('backbone'),
      _                 = require('underscore'),
      loginTemplate  = require('text!./loginTemplate.html'),
      Layout            = require('layouts/loginLayout/layout');

  var LoginPage =  Backbone.View.extend({
    template: _.template(loginTemplate),
    render: function() {
		require(['jquery','jqueryui','jquery_validate','pwstrength','md5','bootstrap','store','workbee','mailcheck', 'cookiepopup','bootstrap_slider','validator','xml2json'], function($){ 	
			
               	    for (var obj in sessionStorage) {
			 //console.log("obj:"+ obj); 
			  if (sessionStorage.hasOwnProperty(obj)  &&  
					obj != "interfaceItemsStorageKey" && 
					obj != "sCountrycode" && 
					obj != "countriesStorageKey" && 
					obj != "languagesStorageKey" ) {
				 sessionStorage.removeItem(obj);					
			  }
			}	
			
			//$.cookieBar({fixed: true, declineButton: true, acceptOnScroll: 200});
			$('#headerName').html("Login");
			// check if browser private mode is activated and ridirect to private mode message
			try {
				localStorage.setItem("storage_LoggedOut_am_dep",true); 			
			} catch (e) {	
				  window.location.href = baseURL+'#/privateMode';				
			}			  
		
		     $(function() {
				// check if browser private mode is activated and ridirect to private mode message
				try {
					localStorage.setItem("storage_LoggedOut_am_dep",true); 
					 for (var obj in sessionStorage) {		
						 sessionStorage.removeItem(obj);
						 sessionStorage.clear();		
					  }			      
				} catch (e) {	
					  window.location.href = baseURL+'#/privateMode';				
				}			
			  });
			  
			   // var sPass;
				if (localStorage.localStorageRememberPwd_am_dep) {		
					if (localStorage.localStorageRememberPwd_am_dep) {									
						$('#save_password_am_dep').prop("checked", true);
						$('#lorganization').val(localStorage.localStorageOrganization_am_dep);
						$('#lusername').val(localStorage.localStorageUsername_am_dep);
						$('#lpassword').val(localStorage.localStoragePassword_am_dep);	
						//sPass = $('#lpassword').val();									
					} else if (!localStorage.localStorageRememberPwd_am_dep){						
						$('#save_password_am_dep').prop("checked", false);
						$('#lorganization').val('');
						$('#lusername').val('');
						$('#lpassword').val('');									
					}
				}				
			
				 $(document).on("click", '#save_password_am_dep', function (e) {							 
					if ($('#save_password_am_dep').prop('checked')===true) {											
						localStorage.localStorageOrganization_am_dep = $('#lorganization').val();
						localStorage.localStorageUsername_am_dep = $('#lusername').val();
						localStorage.localStoragePassword_am_dep = $('#lpassword').val();	
						//sPass = $('#lpassword').val();						
						localStorage.localStorageRememberPwd_am_dep = true; 
					} else if ($('#save_password_am_dep').prop('checked')===false) {
						localStorage.localStorageOrganization_am_dep = '';
						localStorage.localStorageUsername_am_dep = '';
						localStorage.localStoragePassword_am_dep = '';	
						localStorage.localStorageRememberPwd_am_dep = '';	
						$('#lpassword').val('');											
					}				
				});		
	    
			  function getCheckLogin(sOrg, sUser, sPass){	
					var isOK = false;					
					var soapBody =
						[ '<?xml version="1.0" encoding="utf-8"?>'
						,  "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ser=\"http://www.login.absentiemanager.nl/service2\">"
						,  "<soapenv:Header/>"
						,   '<soapenv:Body>'
						,     '<ser:CheckLogin>'
						,       '<ser:login>'
						,         '<ser:Organization>'+sOrg+'</ser:Organization>'
						,         '<ser:Username>'+sUser+'</ser:Username>'
						,         '<ser:Password>'+sPass+'</ser:Password>'			
						,       '</ser:login>'
						,     '</ser:CheckLogin>'
						,   '</soapenv:Body>'
						, '</soapenv:Envelope>'
						].join('');		
			
					  $.ajax({  
						type: "POST",
						url: restURL+"AMS.Service2.cls",	
						async: false,	
						cache: false,			
						data: soapBody,			
						contentType: 'text/xml; charset=utf-8',
						headers: {		
							SOAPAction: 'http://www.login.absentiemanager.nl/service2/AMS.Service2.CheckLogin'
						},
					   success: function(data, status, req){			
							if (status == "success"){  
							  if($.xml2json(data).Body.CheckLoginResponse.CheckLoginResult.errorSpecified == 'false'){
								 isOK = true;
							  } else {
								 isOK = false; 
							  }				
							}
					   },
					   error: function(data, status, req){
							isOK = false;  
							console.log(req.responseText + " " + status);
					 }
					});   
					return isOK;        
				}
				
				 function fncGetEmployeeList(sOrg, sUser, sPass){	
					$.support.cors = true;	
					var soapBody =
						[ '<?xml version="1.0" encoding="utf-8"?>'
						,  "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ser=\"http://www.login.absentiemanager.nl/service2\">"
						,  "<soapenv:Header/>"
						,   '<soapenv:Body>'
						,     '<ser:CheckLogin>'
						,       '<ser:login>'
						,         '<ser:Organization>'+sOrg+'</ser:Organization>'
						,         '<ser:Username>'+sUser+'</ser:Username>'
						,         '<ser:Password>'+sPass+'</ser:Password>'			
						,       '</ser:login>'
						,     '</ser:CheckLogin>'
						,   '</soapenv:Body>'
						, '</soapenv:Envelope>'
						].join('');		
				
					 $.ajax({  
						type: "POST",
						url: restURL+"AMS.Service2.cls",	
						async: false,	
						cache: false,			
						data: soapBody,			
						contentType: 'text/xml; charset=utf-8',
						headers: {		
						SOAPAction: 'http://www.login.absentiemanager.nl/service2/AMS.Service2.GetDepartmentList'
					   },
						success: function(data, status, req){ 																   
							$('#submitbtn').show();	
							// Hide Gif Spinning Rotator
							$('#ajax_loading').hide();  	
							if(status == "success") {  // LOGIN OK? 							
								if($.xml2json(data).Body.GetDepartmentListResponse.GetDepartmentListResult == 'true'){
									alert("Error");
								} else {									 		   
									store.set("AbsDepartmentListStorageKey", $.xml2json(data).Body.GetDepartmentListResponse.GetDepartmentListResult.departments.TypedDepartmentList);							 
									localStorage.setItem("storage_LoggedOut_am_dep",false);								
									store.set("session_Org_am_dep", window.btoa(sOrg)); //window.atob(sOrg)
									store.set("session_User_am_dep",window.btoa(sUser));
									store.set("session_Pass_am_dep",window.btoa(sPass));	 
									store.set("session_toLanguage",'1');
									
									var login_response = '<div id="logged_in">' +
									'<div style="width: 350px; float: left; margin-left: 10px;">' + 
									'<div style="width: 40px; float: left;">' +
									'<img style="margin: 2px 0px 2px 0px;" align="absmiddle" src="img/ajax-loader.gif">' +
									'</div>' +
									'<div style="margin: 2px 0px 0px 2px; float: right; width: 300px;">'+ 
									"U bent succesvol ingelogd! <br /> Een moment geduld aub - bezig met laden...</div></div>"; 
									$('a.modalCloseImg').hide(); 
									$('#login-form').hide();
									
									$('#simplemodal-container').css("width","350px");
									$('#simplemodal-container').css("height","120px"); 
									$(this).html(login_response); // Refers to 'status'
									$('#login_response').html(login_response);				
									setTimeout(function() {			
										window.location.href =  baseURL+'#/dashboard';	
									}, 4000);		
								}	
							} else {  // ERROR?  				
								$('#login_response').html(status);
							}        
							//});  //ajaxComplete
						   
						  }  //success
						});    
						// -- End AJAX Call --
						return false;
				  }
				  
				
			 	// When DOM is ready	
				jQuery(document).ready(function($){		
							
				$("#login-form").validate({
					 errorPlacement: $.noop,		
					//errorElement:'label',		
					// Rules for form validation
					rules : {
						lorganization : {
						required : true,							
					},
						lusername : {
						required : true,						
					},
						lpassword : {
						required : true,				
					}
					},				
					submitHandler : function( form) {
						
						if (localStorage.localStorageRememberPwd_am_dep && localStorage.localStorageRememberPwd_am_dep!=undefined) {							
						     var uName =  window.btoa($("#lusername").val()), pwd =  window.btoa($('#lpassword').val());			
						} else {
							var uName = $("#lusername").val(), pwd = $('#lpassword').val();	
						}	   
						 if (getCheckLogin($("#lorganization").val(),$("#lusername").val(), $('#lpassword').val()) ) {																			
						      fncGetEmployeeList($("#lorganization").val(),$("#lusername").val(), $('#lpassword').val());	
						 } else {
							 $('#login_response').html("Fout");
						 }			 					
							return false;	
						}			
				 });				
				});		
		
       });//require
      this.$el.html(this.template(this));
      return this;
	 
    }
  });

  return Layout.extend({
    content: LoginPage
  });
});
