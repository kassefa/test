define(function(require) {
  'use strict';
  var Backbone          = require('backbone'),
      _                 = require('underscore'),
      registerTemplate  = require('text!./registerTemplate.html'),
      Layout            = require('layouts/loginLayout/layout');

  var RegisterPage =  Backbone.View.extend({
    template: _.template(registerTemplate),
    render: function() {
		require(['jquery','jqueryui','jquery_validate','pwstrength','md5','bootstrap','store','mailcheck', 'cookiepopup','bootstrap_slider','validator'], function($){ 	//,'jquery-validate','pwstrength','workbee',
				
		 for (var obj in sessionStorage) {
			 //console.log("obj:"+ obj); 
			  if (sessionStorage.hasOwnProperty(obj)  &&  
					obj != "interfaceItemsStorageKey" && 
					obj != "sCountrycode" && 
					obj != "countriesStorageKey" && 
					obj != "languagesStorageKey" ) {
				 sessionStorage.removeItem(obj);					
			  }
			}	
				
		   // getBrowserLanguage(bLanguage);								
		
			$.cookieBar({fixed: true, declineButton: true, acceptOnScroll: 200});
			$('#headerName').html("Register");
			// check if browser private mode is activated and ridirect to private mode message
			try {
				localStorage.setItem("storage_LoggedOut",true); 
				localStorage.setItem("storage_LockStatus", "0");
			} catch (e) {	
				  window.location.href = baseURL+'#/privateMode';				
			}				   			  		  
			setTimeout(function(){					
			   if( availableTrans.match(new RegExp("(?:^|,)"+ store.get("sCountrycode")+"(?:,|$)"))) {
				   require([baseURL+'libs/jquery/localization/messages_'+store.get("sCountrycode")+".js"], function ($) {});	
				} else {
				   require([baseURL+'libs/jquery/localization/messages_gb.js'], function ($) {});	
				}
			}, 1000); 	
													
			$(document).on("click", '.sLanguage', function (e) {	
			   var language = $(this).attr('id').toLowerCase();					
			   require([baseURL+'libs/jquery/localization/messages_'+language+".js"], function ($) {});			 
			   if(language == "nl"){					
				  $('#lemail').attr('placeholder', 'Gebruikersnaam / E-mail');  
				  $('#lpassword').attr('placeholder', 'Wachtwoord');   
			   } else {					
				  $('#lemail').attr('placeholder', 'Username / E-mail'); 
				  $('#lpassword').attr('placeholder', 'Password'); 
				}
			});	
			
			function convert_case(str) {
				  var lower = str.toLowerCase();
				  return lower.replace(/(^| )(\w)/g, function(x) {
					return x.toUpperCase();
				  });
				}	   
							
				function fncGetDefaultCountry(sDef){
					var cSelected;	
					$.ajax({
						url: restURL+"getcountries",
				     	contentType: "application/json; charset=utf-8",
  						dataType: "json",					
						cache: false,					
						success: function(cdata) {
							$.each(cdata, function(key, val) {					
							if (sDef.toUpperCase()==val.A2){cSelected = 'selected';} else {cSelected = '';}								
								$('#countryid').append('<option ' +   cSelected + '  value="' + val.ID + '">' + convert_case(val.CountryName)+ '</option>');									
							});		
						},
						error: function (request, status, error) { console.log(status + ", " + error); }
					});
				}
				
				function fncGetDefaultLanguage(sDefault){	
					var lSelected;
					$.ajax({
						url: restURL+"getlanguages",
						contentType: "application/json; charset=utf-8",
  						dataType: "json",					
						success: function(cdata) {						
							$.each(cdata, function(key, val) {		
								if(val.ID == "1" || val.ID == "2") {						
								if (sDefault.toUpperCase()==val.Code){lSelected = 'selected';} else {lSelected = '';}								 							
									$('#languageid').append('<option ' +   lSelected + ' lang-code="' + val.Code + '"  value="' + val.ID + '">' + val.Description + '</option>');	
								}
							});		
						},
						error: function (request, status, error) { console.log(status + ", " + error); }
					});
				}				
			
				function fncGetDefaultGender(){					
					$.ajax({
						url: restURL+"getgenders",
						cache: false,
						dataType: "json",
						success: function(cdata) {
							$('#genderid').append('<option value="" selected  class="sTranslate" key="_account_aanmaken_geslacht_kiezen_">Kies een geslacht</option>');	
							$.each(cdata, function(key, val) {	
							  if (val.ID == '1'){													
								$('#genderid').append('<option class="sTranslate" key="_account_aanmaken_geslacht_m_"  value="' + val.ID + '">' + val.Description + '</option>');	
							  } else if (val.ID == '2') {
								$('#genderid').append('<option class="sTranslate" key="_account_aanmaken_geslacht_v_"  value="' + val.ID + '">' + val.Description + '</option>');	  
							  } else {
								$('#genderid').append('<option class="sTranslate" key="_account_aanmaken_geslacht_o_"  value="' + val.ID + '">' + val.Description + '</option>');	    
							  }
							});		
						},
						error: function (request, status, error) { console.log(status + ", " + error); }
					});
				}			 
				
				function fncGetDefaultLanguageAA(sDef){	
					var gSelected;
					var langObj ={"NL":"Nederlands","GB":"English","DE":"Deutsch","FR":"Frans","ES":"Spaans"};	
					$.each(langObj, function(ckey, cvalue) {
					if (sDef == ckey.toLowerCase()) {gSelected = 'selected';	} else {gSelected = '';	}
						$('#langcode').append('<option ' +   gSelected + '  value="' + ckey+ '">' + cvalue + '</option>');		
					});	
				}		
				
				function fncGetDefaultImages(){	
					$.ajax({
						url: restURL+"getdefaultimages",
						cache: false,
						dataType: "json",
						success: function(cdata) {
							store.set("defaultAvatarF",cdata.defaultAvatarF); 
							store.set("defaultPictureF",cdata.defaultPictureF);
							store.set("defaultAvatarM",cdata.defaultAvatarM); 
							store.set("defaultPictureM",cdata.defaultPictureM);  	
						},
						error: function (request, status, error) { console.log(status + ", " + error); }
					});
				}
				
			$('#genderid').on('change', function() {			
				if (this.value == '1'){
					$('#avatar').val(store.get("defaultAvatarF"));
					$('#picture').val(store.get("defaultPictureF"));	
				} else {
				   $('#avatar').val(store.get("defaultAvatarM"));
				   $('#picture').val(store.get("defaultPictureM"));
				}			
			});		
			
		    $('#languageid').on('change', function(sLanguCode) {	
			    sLanguCode = $(this).find('option:selected').attr("lang-code");			 	 
		    	store.set("sCountrycode",sLanguCode.toLowerCase());	
				$('#langcode').val(sLanguCode);	
			});		
		
			$.fn.formDataToObject = function(){
				var formObj = {}, fields = $(':input').serializeArray();				 
				$.each(fields, function (i, field) {
					//console.log('input' + i + ': ' + field.name + " = " + field.value);				
					if (this.name  == 'rrpassword') { this.value = md5( this.value);} 
					if (this.name  == 'password') { this.value = md5( this.value);} 
					if (formObj[this.name] !== undefined) { 
						if (!formObj[this.name].push) {					
						 formObj[this.name] = [formObj[this.name]];
						}
						formObj[this.name].push(this.value || '');						
					} else {
						formObj[this.name] = this.value || '';					
					}				
				});
				//return JSON.stringify(formObj);
				return formObj;
			};	
				
			$("#i-agree").click(function(){
				var $this=$("#sConfirm");
				if($this.checked) {
					$('#privacyModal').modal('toggle');
				} else {
					$this.prop('checked', true);
					$('#privacyModal').modal('toggle');
				}
			});			 
			
			var optionss = {};
			optionss.ui = {
				container: "#pwd-container",
				showVerdictsInsideProgressBar: true,
				viewports: {
					progress: ".pwstrength_viewport_progress"
				},
				verdicts: store.get("sCountrycode") == "nl" ? ["Zwakke", "Normaal", "Gemiddeld", "Sterk", "Zeer Sterk"] : ["Weak", "Normal", "Medium", "Strong", "Very Strong"],
			};			
			$('#password').pwstrength(optionss);				
			  
		
		    $(function() {
				//fncGetDefaultImages(); 
			    //fncGetDefaultCountry(store.get("sCountrycode").toUpperCase());
				//fncGetDefaultLanguage(store.get("sCountrycode").toUpperCase());	
				//fncGetDefaultGender();			 			      
				$.validator.addMethod(
					'ContainsAtLeastOneDigit',
					function (value) {
					return (/[0-9]/).test(value);
					},
					'<span class="sTranslate" key="_create_account_pass_cri_1_">Uw wachtwoord moet minimaal een cijfer bevatten.</span>'
					);					
					$.validator.addMethod(
					'ContainsAtLeastOneCapitalLetter',
					function (value) {
						return (/[A-Z]/).test(value);
					},
					'<span class="sTranslate" key="_create_account_pass_cri_2_">Uw wachtwoord moet minstens een hoofdletter bevatten.</span>'
				);
			  });					
				
			 $('#workbee-form-register').validate({					
				rules: {
					contactfirstname: {required: true},
					contactmiddlename: {required: false},
					contactlastname: {required: true},
					contactfullname: {required: false},
					contactnickname: {required: false},
					contactinitials: {required: false},
					contactphonenr: {required: false},
					contactmobilenr: {required: false},
					contactdateofbirth: {required: false},
					password: {required: true, ContainsAtLeastOneDigit: true,ContainsAtLeastOneCapitalLetter: true,	minlength: 8},
					rrpassword: {required: true, minlength : 8,	maxlength : 20,	equalTo : '#password'},
					emailaddresslogin: {required: true, email : true},
					sConfirm: {required: true},
					emailaddressrecovery: {required: false},
					emailaddresschange: {required: false},
					isactive: {required: false},
					ipaddress: {required: false},
					picture: {required: false},
					avatar: {required: false},
					contactprefix: {required: false},
					contacttitle: {required: false},
					companyname: {required: false},
					companymainphonenr: {required: false},
					companymainemailaddress: {required: false},
					companymainfaxnr: {required: false},
					companytaxnumber: {required: false},
					companykvknumber: {required: false},
					contactstreet: {required: false},
					contacthousenumber: {required: false},
					contacthousenumberadd: {required: false},
					contactzipcode: {required: false},
					contactcity: {required: false},
					contactpoststreet: {required: false},
					contactposthousenumber: {required: false},
					contactposthousenumberadd: {required: false},
					contactpostzipcode: {required: false},
					contactpostcity: {required: false},
					contactpostbox: {required: false},
					countryid: {required: false},				
					postcountryid: {required: false},
					genderid: {required: true},
					salutationid: {required: false},
					maritalstatusid: {required: false},
					nationality1id: {required: false},
					nationality2id: {required: false},
					companytypeid: {required: false},
					companyindustryid: {required: false},				
					companylanguagechoiceid: {required: false},
					companyrisicopremiegroepid: {required: false},
					langcode: {required: false},
					companyuwvnumber: {required: false},				
					avatarorphoto: {required: false},
					privateaccount: {required: false},				
					accounttypeids: {required: false},
					billingstreet: {required: false},
					billinghousenumber: {required: false},
					billinghousenumberadd: {required: false},				
					billingcity: {required: false},
					billingzipcode: {required: false},				
					billingbanknumber: {required: false},
					billingbankname: {required: false},
					billingcreditcardnumber: {required: false},
					billingpaypalnumber: {required: false},				
					billingstatementttao: {required: false},				
					billingbiccode: {required: false},
					billingfedwire: {required: false},
					workbeeaccountnumber: {required: false},
					companywebsite: {required: false},	
								
				},		
				errorPlacement: function(error, element) {
					error.insertAfter(element.parent());
				},
				submitHandler: function (form) {								
				  	setTimeout(function(){																	
 						fncInsertUserAccount($('#workbee-form-register').formDataToObject());	
						//console.log($('#workbee-form-register').formDataToObject());			  	
					  }, 1000); 	
					return false;		
				 }
				});			
				
				function fncInsertUserAccount(sData){
					$("#msgbox").removeClass().addClass('messagebox').html('<i class="fa fa-gear fa-2x fa-spin"></i>  ....').fadeIn(1000);				
					$.ajax({
						type: "GET",
						url: restURL +"setaccount",  
						data: sData,				
						crossDomain: true,
						dataType: "json",
						success: function (sResponse) {
						if (sResponse.result == 'OK'){	
							setTimeout(function() {
								$("#msgbox").hide();									
									window.location.href = baseURL+'#/bevestigen';													
								$("#msgbox").fadeTo(200,0.1,function() 	{ 				
									$(this).html('<i class="fa fa-check-circle-o fa-2"></i>  ...').addClass('messageboxok').fadeTo(900,1,function(){ });										
								});
							}, 2000);
					
						} else {
							$("#msgbox").hide();	
							var cError;
							if (sResponse.error=='FOUT #5808: Sleutel niet uniek: emailIndex'){
								if (store.get("sCountrycode") == 'nl'){
									cError = 'Dit e-mailadres is al in gebruik. Gelieve een ander e-mailadres'; 	
								} else {
									cError = 'This email address is already in use. Please supply a different email address';
								}
								} else {
									cError = sResponse.error;
								}
							   $('#aanmeldenMessageSpan').css("display", "block");				
							   $('#aanmeldenMessageSpan').html("<p style='color: #FECB01!important;'>"+sResponse.error+"</p>");	
						       $("#msgbox").hide();								
							 }		
						},
						error: function (xhr, ajaxOptions, thrownError) {
						   // error handler		
						    $('#aanmeldenMessageSpan').css("display", "block");	
						   	$('#aanmeldenMessageSpan').html("<p style='color: #FECB01!important;'>"+thrownError+"</p>");	
							$("#msgbox").hide();						
					
						}
					});
				}			
		
       });//require
      this.$el.html(this.template(this));
      return this;
	 
    }
  });

  return Layout.extend({
    content: RegisterPage
  });
});
