define(function(require) {
  'use strict';
  var Backbone          = require('backbone'),
      _                 = require('underscore'),
      settingTemplate  = require('text!./settingTemplate.html'),
      Layout            = require('layouts/dashboardLayout/layout');

  var SettingPage =  Backbone.View.extend({
    template: _.template(settingTemplate),
    model: {},
    render: function() {		
		require(['jquery','jqueryui','jquery_validate','pwstrength','store','mailcheck', 'validator','datatables','datatables_responsive','underscore', 'store'], function($){ 	  	  	   
		  $(document).ready(function() {
		  
		   $('#headerName').html("Setting");		 
		
		  });// ready
		
	    });// require
      this.$el.html(this.template(this));
      return this;
    }//render
  });// view

  return Layout.extend({
    content: SettingPage
  });
});
