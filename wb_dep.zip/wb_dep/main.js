define([], function() {
  'use strict';
  // Configure require.js paths and shims
  require.config({
    paths: {
      'text': 'libs/requirejs-text/text',
      'router': 'libs/requirejs-router/router',
      'backbone': 'libs/backbone/backbone',
      'underscore': 'libs/underscore/underscore',
      'jquery': 'libs/jquery/js/jquery-2.0.2.min',
      'bootstrap': 'libs/bootstrap/js/bootstrap.min',	 
	  'jqueryui':  'libs/jqueryui/js/jquery-ui-1.10.3.min',
	  'md5' :  'libs/md5',	
	  'store':'libs/store',
	  'select2':'libs/select2/js/select2.min', 
	  'datatables':'libs/datatables/jquery.dataTables.min',	
	  'datatables_responsive':'libs/datatable-responsive/js/dataTables.responsive',	
	  'wb_accountInfo' :  'libs/wb_accountInfo',
	  'jquery_validate': 'libs/jquery/jquery.validate',	
	  'pwstrength':'libs/bootstrap/js/pwstrength',	  
	  'workbee':'libs/workbee', 
	  'mailcheck':'libs/mailcheck', 
	  'cookiepopup':'libs/cookiepopup', 
	  'bootstrap_slider':'libs/bootstrap/js/bootstrap-slider', 
	  'validator':'libs/validator', 
	  'xml2json':'libs/jquery.xml2json', 
	  'custumJS':'libs/custom', 	  
	  'datatablesColVis':'libs/datatables/dataTables.colVis.min',
	  'datatablesTools':'libs/datatables/dataTables.tableTools.min',
	  'datatablesBootstrap':'libs/datatables/dataTables.bootstrap.min',
	  'datatablesResponsive':'libs/datatables/dataTables.responsive.min',
	  'dataTablesColumnFilter':'libs/datatables/jquery.dataTables.columnFilter',
    },
    shim: {
     'jquery': {
        exports: '$'
      },
      'underscore': {
        exports: '_'
      },
      'backbone': {
        deps: ['jquery', 'underscore'],
        exports: 'Backbone'
      },
	  'bootstrap': {
        deps: ['jquery'],
      },	
	 'jqueryui': {
        deps: ['jquery'],
      },
	  'md5': {
        deps: ['jquery'],
      },
	  'select2': {
        deps: ['jquery'],
      },
	  'store': {
        deps: ['jquery'],
      },
	  'datatables': {
        deps: ['jquery', 'bootstrap'],
      },
	  'datatables_responsive': {
        deps: ['jquery', 'datatables'],
      },
	 'wb_accountInfo': {
        deps: ['jquery'],
      },
	   'jquery_validate': {
        deps: ['jquery'],
      },
	  'pwstrength': {
        deps: ['jquery', 'bootstrap'],
      },
	  'workbee': {
        deps: ['jquery'],
      },
	  'mailcheck': {
        deps: ['jquery'],
      },
	  'cookiepopup': {
        deps: ['jquery', 'bootstrap'],
      },
	  'bootstrap_slider': {
        deps: ['jquery', 'bootstrap'],
      },
	  'validator': {
        deps: ['jquery', 'bootstrap'],
      },
	  'xml2json': {
        deps: ['jquery'],
      },
	  'custumJS': {
			deps: ['jquery']
	  },	
	'datatablesColVis': {
		deps: ['jquery','datatables','bootstrap']			      
	 },	
	'datatablesTools': {
		deps: ['jquery','datatables','bootstrap']			      
	},	
	'datatablesBootstrap': {
		deps: ['jquery','datatables','bootstrap']			      
	},	
	'datatablesResponsive': {
		deps: ['jquery','datatables','bootstrap']			      
	},	
    }
  });
  // Load the router
  require(['router', 'jquery','store'], function(router, $) {
    // Keep track of the currently loaded view so we can run teardown before loading the new view
    var view;
    router
      .registerRoutes({      
		dashboard: { path: '/dashboard', moduleId: 'pages/dashboard/dashboardPage' },		
		privateMode: { path: '/privateMode', moduleId: 'pages/privateMode/privateModePage' },		
		register: { path: '/register', moduleId: 'pages/register/registerPage' },
        login: { path: '/login', moduleId: 'pages/login/loginPage' },			
		forgotPwd	: { path: '/forgotPwd', moduleId: 'pages/forgotPwd/forgotPwdPage' },		
		notFound: { path: '*', moduleId: 'pages/dashboard/dashboardPage' }
        //notFound: { path: '*', moduleId: 'pages/notFound/notFoundPage' }		
      })
      .on('routeload', function onRouteLoad(View, routeArguments) {
        // When a route loads, render the view and attach it to the document
        if (view) {
          view.remove();
        }
        view = new View(null, routeArguments);
        view.render();
        $('body').append(view.el);
      })
      .init(); // Set up event handlers and trigger the initial page load
  });  
  // requirejs.onError = function (err) {
		//console.log(err.requireType);
		//if (err.requireType === 'timeout') {
		//	console.log('modules: ' + err.requireModules);
		//}	
		//throw err;
	//};	
});
